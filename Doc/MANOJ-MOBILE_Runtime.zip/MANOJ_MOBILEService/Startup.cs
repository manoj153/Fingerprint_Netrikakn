using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(MANOJ_MOBILEService.Startup))]

namespace MANOJ_MOBILEService
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureMobileApp(app);
        }
    }
}